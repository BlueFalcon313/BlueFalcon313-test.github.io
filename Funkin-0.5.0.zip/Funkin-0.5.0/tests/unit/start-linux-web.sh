#!/bin/bash

haxe test-web.hxml
