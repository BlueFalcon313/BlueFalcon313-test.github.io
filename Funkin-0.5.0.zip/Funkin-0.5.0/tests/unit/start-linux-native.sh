#!/bin/bash

haxe test-cpp.hxml
