#!/bin/zsh

haxe test-cpp.hxml
