# Git Hooks
These work even on Windows because of Git Bash.

## Setup
`git config core.hooksPath .github/hooks`
