# funkin.util.plugins

Flixel plugins are objects with `update()` functions that are called from every state.

See: https://github.com/HaxeFlixel/flixel/blob/dev/flixel/system/frontEnds/PluginFrontEnd.hx
