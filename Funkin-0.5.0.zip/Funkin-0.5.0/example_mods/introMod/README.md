# introMod

This intro mod demonstrates two simple things:

1. You can replace any game asset simply by placing a modded asset in the right spot.
2. You can append to text files simply by placing a text file in the right spot, but under the `_append` directory.